function getCalc() {
    let magassag = document.getElementById("magassag").value
    let szelesseg = document.getElementById("szelesseg").value
    let papirtipusa = document.getElementById("papirtipus").value

    let terulet = Math.round((szelesseg * magassag) / 1000)
    let koltseg = terulet * papirtipusa
    console.log(terulet)
    console.log(koltseg)
    document.getElementById("terulet").innerText = terulet;
    document.getElementById("koltseg").innerText = koltseg;

    if(magassag && szelesseg < 50) {
        alert("Ellenőrizze az adatokat!")
    }else {
        document.getElementById("koltseg").style.color = "green";
        document.getElementById("koltseg").style.backgroundColor = "white";
        document.getElementById("kolteg").style.fontWeight = "bold";

    }
    document.getElementById("koltseg").style.backgroundColor = "white";

    if(koltseg > 500) {
        document.getElementById("koltseg").style.color = "red";
    }else {
        document.getElementById("koltseg").style.color = "green";
        document.getElementById("kolteg").style.fontWeight = "bold";
    }
}