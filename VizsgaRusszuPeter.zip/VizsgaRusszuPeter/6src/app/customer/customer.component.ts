import { Component } from '@angular/core';
import { FormBuilder, Validators} from '@angular/forms';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent {
  urlap: any
  constructor(private forms: FormBuilder){}

  ngOninit() {
    this.urlap.this.form.group({

      name: ["", [
        Validators.required
      ]],
      email: ["", [
        Validators.required,
        Validators.email
      ]],
      checkbox: [false, [
        Validators.requiredTrue
      ]]
    })
  }
  get names(){
    return this.urlap.get("home");
  }
  get emails(){
    return this.urlap.get("email");
  }
  get check(){
    return this.urlap.get("checkbox");
  }
}


