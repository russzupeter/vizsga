import { Component } from '@angular/core';
import { ApiService } from '../services/api.service';


@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent {
  
  data: any;
  constructor(private api: ApiService){
    this.api.getData().subscribe(res => {
      this.data = res
    })
  }
}
